from distutils.core import setup

setup(
    name='RC',
    version='v1.0',
    py_modules=['RC.renders','RC.models','RC.preproc']
)


