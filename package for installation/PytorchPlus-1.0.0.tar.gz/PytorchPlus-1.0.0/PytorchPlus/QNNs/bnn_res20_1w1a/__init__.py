from . import __main__
__all__ = ["__main__"]