from . import ir_1w1a
__all__ = ["ir_1w1a"]